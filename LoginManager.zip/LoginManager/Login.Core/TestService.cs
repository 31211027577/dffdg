﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Login.Core
{
    public class TestService
    {
        public TestService(Database database)
        {
            this.database = database;
        }
        private readonly Database database;

        public int Test(int a, int b, int c)
        {
            string name = $"{a}_{b}_{c}";
            string nameActual = database.GetPass(name);
            if (string.IsNullOrWhiteSpace(nameActual))
            {
                throw new ArgumentException("The Name is wrong");
            }
            int t = 5;
            switch (a)
            {
                case 5:
                    if (b > 9)
                    {

                        for (int i = 0; i < c; i++)
                        {
                            t += 1;
                        }
                    }
                    else t = 8;
                    break;
                case 7:
                    if ((b < 10) || (b > 100)) t = 10;
                    else if (c >= 3) t = 3;
                    else t = 4;
                    break;

            }
            return t;
        }
    }
}
