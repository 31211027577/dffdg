﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Login.Core
{
    public class Database
    {
        public virtual string GetPass(string user)
        {
            throw new NotImplementedException();
        }
    }
}
