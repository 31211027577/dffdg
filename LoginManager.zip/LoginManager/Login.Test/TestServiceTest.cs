﻿using Login.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.CodeDom;

namespace Login.Test
{
    using Login.Core;
    using System.ComponentModel;

    [TestClass]
    public class TestServiceTest
    {


        [TestMethod]
        public void TestMethod1() // a=5; b>9
        {
            TestService testService = new TestService(new DatabaseStub());
            try
            {
                int a = 5; int b = 10; int c = 3;
                Assert.AreEqual(9, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(),typeof(ArgumentException));
            }
            
        }

        [TestMethod]
        public void TestMethod2()  // a=5;b<=9
        {
         
            TestService testService = new TestService(new DatabaseStub());
            try
            {
                int a = 5; int b = 9; int c = 3;
                Assert.AreEqual(8, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(), typeof(ArgumentException));
            }
        }

        [TestMethod]
        public void TestMethod3() //a=7; b<10
        {

            TestService testService = new TestService(new DatabaseStub());
            try
            {
                int a = 7; int b = 8; int c = 3;
                Assert.AreEqual(10, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(), typeof(ArgumentException));
            }

        }

        [TestMethod]
        public void TestMethod4() // a=7; b>100
        {

            TestService testService = new TestService(new DatabaseStub());
            try
            {
                int a = 5; int b = 101; int c = 3;
                Assert.AreEqual(10, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(), typeof(ArgumentException));
            }
        }

        [TestMethod]
        public void TestMethod5()  // a=7; 10<=b<=100; c>=3
        {

            // Arrange
            int a = 5;
            int b = 45;
            int c = 3;

            
            int expected5 = 3;

            TestService testService = new TestService(new DatabaseStub());
            try
            {
                Assert.AreEqual(expected5, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(), typeof(ArgumentException));
            }
        }

        [TestMethod]
        public void TestMethod6()  // a=7; 10<=b<=100; c<3
        {

            // Arrange
            int a = 5;
            int b = 45;
            int c = 0;

            
            int expected6 = 4;

            TestService testService = new TestService(new DatabaseStub());
            try
            {
                Assert.AreEqual(expected6, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(), typeof(ArgumentException));
            }
        }


        [TestMethod]
        public void TestMethod7()  // a khác 5; a khác 7
        {

            // Arrange
            int a = 10;
            int b = 5;
            int c = 2;

            
            int expected7 = 5;

            TestService testService = new TestService(new DatabaseStub());
            try
            {
                Assert.AreEqual(expected7, testService.Test(a, b, c));
            }
            catch (Exception e)
            {
                Assert.AreEqual(e.GetType(), typeof(ArgumentException));
            }
        }

    }
}
